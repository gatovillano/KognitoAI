"""cli/__main__.py — python -m cli"""
from cli.main import main
if __name__ == "__main__":
    main()
