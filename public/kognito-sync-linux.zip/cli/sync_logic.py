import os
import sqlite3
import httpx
import time
import logging
from datetime import datetime
from watchdog.observers import Observer
from watchdog.events import FileSystemEventHandler

logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger("KognitoSync")

class LocalChangeHandler(FileSystemEventHandler):
    def __init__(self, sync_manager):
        self.sync_manager = sync_manager

    def on_modified(self, event):
        if not event.is_directory:
            self.sync_manager.handle_local_change(event.src_path, "modify")

    def on_created(self, event):
        if not event.is_directory:
            self.sync_manager.handle_local_change(event.src_path, "create")
        else:
            self.sync_manager.handle_local_dir_created(event.src_path)

    def on_deleted(self, event):
        if not event.is_directory:
            self.sync_manager.handle_local_change(event.src_path, "delete")
        else:
            self.sync_manager.handle_local_dir_deleted(event.src_path)

    def on_moved(self, event):
        self.sync_manager.handle_local_move(event.src_path, event.dest_path, event.is_directory)

class KognitoSyncManager:
    def __init__(self, server_url, username, password, sync_dir, db_path):
        self.server_url = server_url.rstrip('/')
        self.username = username
        self.password = password
        self.sync_dir = os.path.abspath(sync_dir)
        self.db_path = os.path.abspath(db_path)
        self.token = None
        self.is_running = False
        self.observer = None
        self._suppress_watchdog = False
        self.init_db()

    def init_db(self):
        os.makedirs(os.path.dirname(self.db_path), exist_ok=True)
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS sync_files (
                local_path TEXT PRIMARY KEY,
                document_id TEXT NOT NULL,
                workspace_id TEXT,
                folder_id TEXT,
                last_seen_mtime REAL NOT NULL,
                last_seen_updated_at TEXT NOT NULL
            )
        """)
        conn.commit()
        conn.close()

    def login(self):
        url = f"{self.server_url}/api/auth/login"
        try:
            # fastapi expects username/password form fields for standard OAuth2 login
            data = {"username": self.username, "password": self.password}
            resp = httpx.post(url, data=data)
            if resp.status_code == 200:
                self.token = resp.json().get("access_token")
                logger.info("Autenticación exitosa.")
                return True
            else:
                # Try json as backup
                resp = httpx.post(url, json=data)
                if resp.status_code == 200:
                    self.token = resp.json().get("access_token")
                    logger.info("Autenticación exitosa (JSON).")
                    return True
                logger.error(f"Error de login: {resp.status_code} - {resp.text}")
                return False
        except Exception as e:
            logger.error(f"Error al conectar para login: {e}")
            return False

    def get_auth_headers(self):
        return {"Authorization": f"Bearer {self.token}"} if self.token else {}

    def fetch_remote_workspaces(self):
        url = f"{self.server_url}/api/workspaces?limit=100"
        try:
            resp = httpx.get(url, headers=self.get_auth_headers())
            if resp.status_code == 200:
                data = resp.json()
                if isinstance(data, dict) and "workspaces" in data:
                    return data["workspaces"]
                elif isinstance(data, list):
                    return data
            logger.error(f"Error buscando workspaces remotos: {resp.status_code}")
            return []
        except Exception as e:
            logger.error(f"Error buscando workspaces remotos: {e}")
            return []

    def fetch_remote_folders(self):
        url = f"{self.server_url}/api/onlyoffice/folders"
        try:
            resp = httpx.get(url, headers=self.get_auth_headers())
            if resp.status_code == 200:
                return resp.json()
            logger.error(f"Error buscando carpetas remotas: {resp.status_code}")
            return None
        except Exception as e:
            logger.error(f"Error buscando carpetas remotas: {e}")
            return None

    def fetch_remote_documents(self):
        url = f"{self.server_url}/api/onlyoffice/list"
        try:
            resp = httpx.get(url, headers=self.get_auth_headers())
            if resp.status_code == 200:
                return resp.json()
            logger.error(f"Error buscando documentos remotos: {resp.status_code}")
            return None
        except Exception as e:
            logger.error(f"Error buscando documentos remotos: {e}")
            return None

    def create_remote_folder(self, name, workspace_id=None, parent_id=None):
        url = f"{self.server_url}/api/onlyoffice/folders"
        data = {"name": name}
        if workspace_id:
            data["workspace_id"] = str(workspace_id)
        if parent_id:
            data["parent_id"] = str(parent_id)
        try:
            resp = httpx.post(url, headers=self.get_auth_headers(), data=data)
            if resp.status_code in [200, 201]:
                res_json = resp.json()
                new_id = str(res_json.get("id"))
                logger.info(f"Carpeta remota '{name}' creada con ID: {new_id} (workspace={workspace_id}, parent={parent_id})")
                return new_id
            logger.error(f"Error creando carpeta remota '{name}': {resp.status_code} - {resp.text}")
            return None
        except Exception as e:
            logger.error(f"Excepción creando carpeta remota '{name}': {e}")
            return None

    def build_folder_map(self, folders):
        folder_map = {}
        if folders:
            for f in folders:
                folder_map[str(f["id"])] = {
                    "id": str(f["id"]),
                    "name": f["name"],
                    "parent_id": str(f["parent_id"]) if f.get("parent_id") else None,
                    "workspace_id": str(f["workspace_id"]) if f.get("workspace_id") else None,
                    "workspace_name": f.get("workspace_name")
                }
        return folder_map

    def resolve_folder_path(self, folder_id, folder_map):
        if not folder_id:
            return ""
        parts = []
        curr_id = str(folder_id)
        visited = set()
        while curr_id and curr_id not in visited:
            visited.add(curr_id)
            folder = folder_map.get(curr_id)
            if not folder:
                break
            parts.insert(0, folder["name"])
            curr_id = str(folder["parent_id"]) if folder.get("parent_id") else None
        return os.path.join(*parts) if parts else ""

    def ensure_remote_folder_chain(self, folder_names, workspace_id, folder_map):
        """
        Garantiza que la cadena de subcarpetas exista en la nube (remoto).
        folder_names: lista de nombres de subcarpetas en orden, ej: ["Carpeta1", "Sub2"]
        workspace_id: ID del workspace (o None para Personal)
        folder_map: dict de folder_id -> folder_data
        Retorna el folder_id de la carpeta final (o None si folder_names está vacío).
        """
        if not folder_names:
            return None
            
        curr_parent_id = None
        for name in folder_names:
            found_id = None
            for fid, f in folder_map.items():
                f_ws = f.get("workspace_id")
                f_parent = f.get("parent_id")
                
                ws_match = (str(f_ws) == str(workspace_id)) if (f_ws and workspace_id) else (not f_ws and not workspace_id)
                parent_match = (str(f_parent) == str(curr_parent_id)) if (f_parent and curr_parent_id) else (not f_parent and not curr_parent_id)
                
                if f.get("name") == name and ws_match and parent_match:
                    found_id = str(fid)
                    break
            
            if found_id:
                curr_parent_id = found_id
            else:
                created_id = self.create_remote_folder(name, workspace_id=workspace_id, parent_id=curr_parent_id)
                if not created_id:
                    logger.error(f"Fallo al asegurar carpeta remota '{name}'")
                    return None
                folder_map[created_id] = {
                    "id": created_id,
                    "name": name,
                    "parent_id": curr_parent_id,
                    "workspace_id": str(workspace_id) if workspace_id else None,
                    "workspace_name": None
                }
                curr_parent_id = created_id
                
        return curr_parent_id

    def resolve_local_path_hierarchy(self, local_path, folder_map=None, workspaces=None):
        """
        Analiza la ruta local de un archivo y determina:
        1. Si necesita reubicación a Personal/ (si está en la raíz o en una carpeta que no es workspace)
        2. El workspace_id correspondiente
        3. El folder_id remoto correspondiente, creando las carpetas faltantes en el servidor si es necesario.
        Retorna (local_path_actualizado, workspace_id, folder_id, folder_map)
        """
        rel_path = os.path.relpath(local_path, self.sync_dir)
        parts = rel_path.split(os.sep)
        filename = parts[-1]

        if workspaces is None:
            workspaces = self.fetch_remote_workspaces() or []
        ws_name_to_id = {w["name"]: str(w["id"]) for w in workspaces}

        if len(parts) == 1:
            # Archivo directamente en la raíz -> Mover a Personal/filename
            personal_dir = os.path.join(self.sync_dir, "Personal")
            os.makedirs(personal_dir, exist_ok=True)
            target_path = os.path.join(personal_dir, filename)
            try:
                os.rename(local_path, target_path)
                logger.info(f"Archivo movido de raíz a carpeta Personal: {local_path} -> {target_path}")
                local_path = target_path
            except Exception as e:
                logger.error(f"No se pudo mover archivo raíz a Personal: {e}")
            rel_path = os.path.relpath(local_path, self.sync_dir)
            parts = rel_path.split(os.sep)

        # Si el primer directorio no es 'Personal' ni el nombre de un workspace existente,
        # significa que es una carpeta personal creada en la raíz (ej: ~/KognitoSync/MiCarpeta/...)
        if parts[0] != "Personal" and parts[0] not in ws_name_to_id:
            target_path = os.path.join(self.sync_dir, "Personal", rel_path)
            os.makedirs(os.path.dirname(target_path), exist_ok=True)
            try:
                os.rename(local_path, target_path)
                logger.info(f"Ruta reubicada dentro de Personal: {local_path} -> {target_path}")
                local_path = target_path
            except Exception as e:
                logger.error(f"No se pudo reubicar bajo Personal: {e}")
            rel_path = os.path.relpath(local_path, self.sync_dir)
            parts = rel_path.split(os.sep)

        if parts[0] == "Personal":
            workspace_id = None
            folder_names = parts[1:-1]
        elif parts[0] in ws_name_to_id:
            workspace_id = ws_name_to_id[parts[0]]
            folder_names = parts[1:-1]
        else:
            workspace_id = None
            folder_names = parts[1:-1]

        if folder_map is None:
            folders = self.fetch_remote_folders() or []
            folder_map = self.build_folder_map(folders)

        folder_id = self.ensure_remote_folder_chain(folder_names, workspace_id, folder_map)
        return local_path, workspace_id, folder_id, folder_map

    def update_remote_doc_meta(self, doc_id, filename=None, workspace_id=None, folder_id=None):
        url = f"{self.server_url}/api/onlyoffice/{doc_id}/meta"
        data = {}
        if filename:
            data["filename"] = filename
        data["workspace_id"] = str(workspace_id) if workspace_id else "null"
        data["folder_id"] = str(folder_id) if folder_id else "null"
        try:
            resp = httpx.post(url, headers=self.get_auth_headers(), data=data)
            if resp.status_code == 200:
                logger.info(f"Metadatos remotos actualizados para documento ID: {doc_id}")
                return True
            logger.error(f"Error al actualizar metadatos remotos ({doc_id}): {resp.status_code} - {resp.text}")
            return False
        except Exception as e:
            logger.error(f"Excepción al actualizar metadatos remotos ({doc_id}): {e}")
            return False

    def sync_pass(self):
        if not self.token and not self.login():
            logger.error("No se pudo iniciar sesión. Saltando ciclo de sincronización.")
            return

        logger.info("Iniciando ciclo de sincronización...")
        self._suppress_watchdog = True
        
        try:
            # 1. Obtener estado de la nube
            workspaces = self.fetch_remote_workspaces() or []
            
            folders = self.fetch_remote_folders()
            if folders is None:
                logger.error("No se pudieron obtener carpetas remotas. Cancelando ciclo de sync para proteger archivos locales.")
                return
            folder_map = self.build_folder_map(folders)

            # Asegurar que todas las carpetas remotas existan localmente (incluso carpetas vacías)
            os.makedirs(os.path.join(self.sync_dir, "Personal"), exist_ok=True)
            for f in folders:
                ws_dir = f["workspace_name"] if f.get("workspace_name") else "Personal"
                f_subpath = self.resolve_folder_path(f["id"], folder_map)
                local_folder_dir = os.path.join(self.sync_dir, ws_dir, f_subpath)
                os.makedirs(local_folder_dir, exist_ok=True)

            remote_docs = self.fetch_remote_documents()
            if remote_docs is None:
                logger.error("No se pudieron obtener documentos remotos. Cancelando ciclo de sync para proteger archivos locales.")
                return
            
            # Map remote docs por ruta local esperada y por document_id
            remote_by_path = {}
            remote_by_doc_id = {}
            for doc in remote_docs:
                ws_dir = doc["workspace_name"] if doc["workspace_name"] else "Personal"
                folder_subpath = self.resolve_folder_path(doc.get("folder_id"), folder_map)
                rel_path = os.path.join(ws_dir, folder_subpath, doc["filename"])
                local_path = os.path.join(self.sync_dir, rel_path)
                remote_by_path[local_path] = doc
                remote_by_doc_id[doc["id"]] = (local_path, doc)

            # 2. Conectar a SQLite
            conn = sqlite3.connect(self.db_path)
            conn.row_factory = sqlite3.Row
            cursor = conn.cursor()
            
            # Obtener todos los registros locales
            cursor.execute("SELECT * FROM sync_files")
            local_db_records = {r["local_path"]: dict(r) for r in cursor.fetchall()}
            local_db_by_doc_id = {r["document_id"]: dict(r) for r in local_db_records.values() if r.get("document_id")}

            # 3. Procesar cambios de Nube -> Local
            for local_path, rdoc in remote_by_path.items():
                doc_id = rdoc["id"]
                db_rec = local_db_records.get(local_path)
                
                # Si la ruta no coincide exactamente pero el document_id ya está en SQLite
                if not db_rec and doc_id in local_db_by_doc_id:
                    existing_rec = local_db_by_doc_id[doc_id]
                    old_path = existing_rec["local_path"]
                    if os.path.exists(old_path) and old_path != local_path:
                        os.makedirs(os.path.dirname(local_path), exist_ok=True)
                        try:
                            os.rename(old_path, local_path)
                            logger.info(f"Reubicando rastro local: {old_path} -> {local_path}")
                        except Exception as e:
                            logger.error(f"Error reubicando rastro local: {e}")
                    cursor.execute("""
                        UPDATE sync_files 
                        SET local_path = ?, workspace_id = ?, folder_id = ?, last_seen_updated_at = ? 
                        WHERE document_id = ?
                    """, (local_path, rdoc.get("workspace_id"), rdoc.get("folder_id"), rdoc.get("updated_at", ""), doc_id))
                    db_rec = existing_rec
                    db_rec["local_path"] = local_path

                # Caso 1: Archivo remoto es totalmente nuevo para nosotros
                if not db_rec:
                    if os.path.exists(local_path):
                        self.rename_to_conflict(local_path)
                    
                    self.download_file(rdoc["id"], local_path)
                    self.register_in_db(cursor, local_path, rdoc["id"], rdoc.get("workspace_id"), rdoc.get("folder_id"), rdoc.get("updated_at", ""))
                    
                # Caso 2: Registrado en DB local
                else:
                    # Comprobar si el archivo remoto fue editado
                    if rdoc.get("updated_at") != db_rec.get("last_seen_updated_at"):
                        local_modified = False
                        if os.path.exists(local_path):
                            curr_mtime = os.path.getmtime(local_path)
                            if abs(curr_mtime - db_rec.get("last_seen_mtime", 0)) > 1.0: # diferencia > 1s
                                local_modified = True
                        
                        if local_modified:
                            logger.warning(f"Conflicto de edición en: {local_path}. Creando copia local de conflicto.")
                            self.rename_to_conflict(local_path)
                            
                        self.download_file(rdoc["id"], local_path)
                        self.register_in_db(cursor, local_path, rdoc["id"], rdoc.get("workspace_id"), rdoc.get("folder_id"), rdoc.get("updated_at", ""))

            # 4. Procesar cambios de Local -> Nube (Archivos que están en DB o disco pero no en remoto)
            for local_path, db_rec in list(local_db_records.items()):
                doc_id = db_rec.get("document_id")

                if local_path not in remote_by_path:
                    # 4.1 Comprobar si el documento existe en la nube pero en una ruta reubicada
                    if doc_id and doc_id in remote_by_doc_id:
                        new_expected_path, rdoc = remote_by_doc_id[doc_id]
                        if os.path.exists(local_path) and local_path != new_expected_path:
                            os.makedirs(os.path.dirname(new_expected_path), exist_ok=True)
                            if not os.path.exists(new_expected_path):
                                try:
                                    os.rename(local_path, new_expected_path)
                                    logger.info(f"Archivo reubicado automáticamente: {local_path} -> {new_expected_path}")
                                except Exception as e:
                                    logger.error(f"Error reubicando archivo: {e}")
                        cursor.execute("DELETE FROM sync_files WHERE local_path = ?", (local_path,))
                        mtime = os.path.getmtime(new_expected_path) if os.path.exists(new_expected_path) else 0
                        cursor.execute("""
                            INSERT OR REPLACE INTO sync_files (local_path, document_id, workspace_id, folder_id, last_seen_mtime, last_seen_updated_at)
                            VALUES (?, ?, ?, ?, ?, ?)
                        """, (new_expected_path, doc_id, rdoc.get("workspace_id"), rdoc.get("folder_id"), mtime, rdoc.get("updated_at", "")))
                        continue

                    # 4.2 Si el archivo existe físicamente, NO lo borramos a ciegas. Lo re-subimos respetando jerarquía.
                    if os.path.exists(local_path):
                        logger.info(f"Re-subiendo archivo local presente en disco a la nube: {local_path}")
                        self.upload_new_file(cursor, local_path, folder_map=folder_map, workspaces=workspaces)
                    else:
                        cursor.execute("DELETE FROM sync_files WHERE local_path = ?", (local_path,))

            # Buscar archivos locales no registrados para subida
            for root, dirs, files in os.walk(self.sync_dir):
                dirs[:] = [d for d in dirs if not d.startswith('.')]
                for f in files:
                    if f.startswith('~$') or f.startswith('.'):
                        continue
                    full_path = os.path.join(root, f)
                    if full_path not in local_db_records and full_path not in remote_by_path:
                        self.upload_new_file(cursor, full_path, folder_map=folder_map, workspaces=workspaces)

            conn.commit()
            conn.close()
            logger.info("Ciclo de sincronización terminado.")
        finally:
            self._suppress_watchdog = False

    def rename_to_conflict(self, local_path):
        dir_name = os.path.dirname(local_path)
        base_name = os.path.basename(local_path)
        name_parts = os.path.splitext(base_name)
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        new_name = f"{name_parts[0]}_conflicto_{timestamp}{name_parts[1]}"
        new_path = os.path.join(dir_name, new_name)
        try:
            os.rename(local_path, new_path)
            logger.info(f"Archivo en conflicto renombrado a: {new_path}")
        except Exception as e:
            logger.error(f"No se pudo renombrar el conflicto {local_path}: {e}")

    def download_file(self, document_id, dest_path):
        os.makedirs(os.path.dirname(dest_path), exist_ok=True)
        url = f"{self.server_url}/api/onlyoffice/download/{document_id}"
        logger.info(f"Descargando archivo {document_id} a {dest_path}...")
        try:
            with httpx.stream("GET", url, headers=self.get_auth_headers()) as r:
                if r.status_code == 200:
                    with open(dest_path, "wb") as f:
                        for chunk in r.iter_bytes():
                            f.write(chunk)
                    logger.info(f"Descarga completada para {dest_path}.")
                else:
                    logger.error(f"Fallo al descargar {document_id}: {r.status_code}")
        except Exception as e:
            logger.error(f"Error en descarga ({document_id}): {e}")

    def upload_new_file(self, cursor, local_path, folder_map=None, workspaces=None):
        if not os.path.exists(local_path):
            return

        filename = os.path.basename(local_path)
        if filename.startswith("~$") or filename.startswith("."):
            return

        # Resolver la jerarquía de directorios (workspace y carpetas anidadas)
        local_path, workspace_id, folder_id, folder_map = self.resolve_local_path_hierarchy(
            local_path, folder_map=folder_map, workspaces=workspaces
        )
        filename = os.path.basename(local_path)

        logger.info(f"Subiendo nuevo archivo local: {local_path} (workspace_id={workspace_id}, folder_id={folder_id})")
        
        url = f"{self.server_url}/api/onlyoffice/upload"
        try:
            with open(local_path, "rb") as f:
                files = {"file": (filename, f, "application/octet-stream")}
                data = {}
                if workspace_id:
                    data["workspace_id"] = str(workspace_id)
                if folder_id:
                    data["folder_id"] = str(folder_id)
                
                resp = httpx.post(url, headers=self.get_auth_headers(), files=files, data=data)
                if resp.status_code == 200:
                    res_json = resp.json()
                    doc_id = res_json["id"]
                    mtime = os.path.getmtime(local_path)
                    
                    updated_at = res_json.get("updated_at")
                    if not updated_at:
                        updated_at = datetime.now().isoformat()

                    self.register_in_db(cursor, local_path, doc_id, workspace_id, folder_id, updated_at)
                    logger.info(f"Subido con éxito: {filename} (ID: {doc_id}, folder_id: {folder_id})")
                else:
                    logger.error(f"Error subiendo archivo {filename}: {resp.status_code} - {resp.text}")
        except Exception as e:
            logger.error(f"Error en subida de {local_path}: {e}")

    def handle_local_change(self, local_path, change_type):
        if not self.is_running or self._suppress_watchdog:
            return
        
        filename = os.path.basename(local_path)
        if filename.startswith("~$") or filename.startswith("."):
            return
            
        logger.info(f"Cambio local detectado: {local_path} ({change_type})")
        time.sleep(0.5)
        
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        try:
            if change_type in ["create", "modify"]:
                cursor.execute("SELECT * FROM sync_files WHERE local_path = ?", (local_path,))
                row = cursor.fetchone()
                if row:
                    doc_id = row[1]
                    logger.info(f"Actualizando contenido remoto para ID: {doc_id}")
                    url = f"{self.server_url}/api/onlyoffice/{doc_id}"
                    try:
                        with open(local_path, "rb") as f:
                            files = {"file": (os.path.basename(local_path), f, "application/octet-stream")}
                            resp = httpx.put(url, headers=self.get_auth_headers(), files=files)
                            if resp.status_code == 200:
                                res_json = resp.json()
                                updated_at = res_json.get("updated_at", datetime.now().isoformat())
                                mtime = os.path.getmtime(local_path)
                                cursor.execute("""
                                    UPDATE sync_files SET last_seen_mtime = ?, last_seen_updated_at = ?
                                    WHERE local_path = ?
                                """, (mtime, updated_at, local_path))
                                logger.info(f"Actualizado exitosamente en el servidor.")
                            else:
                                logger.error(f"Error al actualizar archivo: {resp.status_code} - {resp.text}")
                    except Exception as e:
                        logger.error(f"Error en PUT: {e}")
                else:
                    self.upload_new_file(cursor, local_path)
                    
            elif change_type == "delete":
                cursor.execute("SELECT * FROM sync_files WHERE local_path = ?", (local_path,))
                row = cursor.fetchone()
                if row:
                    doc_id = row[1]
                    logger.info(f"Eliminando documento remoto ID: {doc_id}")
                    url = f"{self.server_url}/api/onlyoffice/{doc_id}"
                    try:
                        resp = httpx.delete(url, headers=self.get_auth_headers())
                        if resp.status_code == 200:
                            cursor.execute("DELETE FROM sync_files WHERE local_path = ?", (local_path,))
                            logger.info("Eliminado exitosamente del servidor.")
                        else:
                            logger.error(f"Error al eliminar en servidor: {resp.status_code} - {resp.text}")
                    except Exception as e:
                        logger.error(f"Error en DELETE: {e}")
            conn.commit()
        finally:
            conn.close()

    def handle_local_dir_created(self, dir_path):
        if not self.is_running or self._suppress_watchdog:
            return
        rel_path = os.path.relpath(dir_path, self.sync_dir)
        if rel_path == "." or rel_path.startswith("."):
            return
        logger.info(f"Directorio local creado: {dir_path}")
        try:
            dummy_file_path = os.path.join(dir_path, ".kognito_probe")
            self.resolve_local_path_hierarchy(dummy_file_path)
        except Exception as e:
            logger.error(f"Error al procesar creación de directorio {dir_path}: {e}")

    def handle_local_dir_deleted(self, dir_path):
        if not self.is_running or self._suppress_watchdog:
            return
        logger.info(f"Directorio local eliminado: {dir_path}")

    def handle_local_move(self, src_path, dest_path, is_directory=False):
        if not self.is_running or self._suppress_watchdog:
            return
            
        logger.info(f"Movimiento local detectado: {src_path} -> {dest_path} (is_dir={is_directory})")
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        try:
            if is_directory:
                cursor.execute("SELECT * FROM sync_files WHERE local_path LIKE ?", (src_path + "/%",))
                rows = cursor.fetchall()
                for row in rows:
                    old_file_path = row[0]
                    doc_id = row[1]
                    rel_inside = os.path.relpath(old_file_path, src_path)
                    new_file_path = os.path.join(dest_path, rel_inside)
                    
                    new_file_path, workspace_id, folder_id, _ = self.resolve_local_path_hierarchy(new_file_path)
                    self.update_remote_doc_meta(doc_id, filename=os.path.basename(new_file_path), workspace_id=workspace_id, folder_id=folder_id)
                    mtime = os.path.getmtime(new_file_path) if os.path.exists(new_file_path) else row[4]
                    cursor.execute("""
                        UPDATE sync_files SET local_path = ?, workspace_id = ?, folder_id = ?, last_seen_mtime = ?
                        WHERE document_id = ?
                    """, (new_file_path, workspace_id, folder_id, mtime, doc_id))
            else:
                filename = os.path.basename(dest_path)
                if filename.startswith("~$") or filename.startswith("."):
                    return
                cursor.execute("SELECT * FROM sync_files WHERE local_path = ?", (src_path,))
                row = cursor.fetchone()
                if row:
                    doc_id = row[1]
                    dest_path, workspace_id, folder_id, _ = self.resolve_local_path_hierarchy(dest_path)
                    self.update_remote_doc_meta(doc_id, filename=os.path.basename(dest_path), workspace_id=workspace_id, folder_id=folder_id)
                    mtime = os.path.getmtime(dest_path) if os.path.exists(dest_path) else row[4]
                    cursor.execute("""
                        UPDATE sync_files SET local_path = ?, workspace_id = ?, folder_id = ?, last_seen_mtime = ?
                        WHERE document_id = ?
                    """, (dest_path, workspace_id, folder_id, mtime, doc_id))
                else:
                    self.upload_new_file(cursor, dest_path)
            conn.commit()
        finally:
            conn.close()

    def register_in_db(self, cursor, local_path, doc_id, workspace_id, folder_id, updated_at):
        mtime = os.path.getmtime(local_path) if os.path.exists(local_path) else 0
        cursor.execute("""
            INSERT OR REPLACE INTO sync_files (local_path, document_id, workspace_id, folder_id, last_seen_mtime, last_seen_updated_at)
            VALUES (?, ?, ?, ?, ?, ?)
        """, (local_path, doc_id, workspace_id, folder_id, mtime, updated_at))

    def start_watching(self):
        if self.observer:
            try:
                self.observer.stop()
            except Exception:
                pass
        self.observer = Observer()
        event_handler = LocalChangeHandler(self)
        self.observer.schedule(event_handler, self.sync_dir, recursive=True)
        self.observer.start()
        logger.info(f"Iniciado monitoreo local de {self.sync_dir}")

    def stop_watching(self):
        if self.observer:
            self.observer.stop()
            self.observer.join()
            self.observer = None
            logger.info("Monitoreo local detenido.")

    def run_sync_loop(self):
        self.is_running = True
        self.start_watching()
        
        while self.is_running:
            try:
                self.sync_pass()
            except Exception as e:
                logger.error(f"Error en ciclo de sincronización: {e}")
            time.sleep(60)

    def stop(self):
        self.is_running = False
        self.stop_watching()
